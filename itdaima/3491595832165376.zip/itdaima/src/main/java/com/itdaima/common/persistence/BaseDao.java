/**
 *
 */
package com.itdaima.common.persistence;

/**
 * DAO支持类实现
 * @author ThinkGem
 * @version 2014-05-16
 */
public interface BaseDao {

}