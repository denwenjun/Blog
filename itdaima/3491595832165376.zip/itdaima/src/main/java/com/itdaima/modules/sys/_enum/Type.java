package com.itdaima.modules.sys._enum;

/**
 * 发表内容类型
 * Created by Administrator on 2017/7/22.
 */

public enum Type {

}
