package com.itdaima.common.beanvalidator;

/**
 * 添加Bean验证组
 * @author ThinkGem
 *
 */
public interface AddGroup {

}
