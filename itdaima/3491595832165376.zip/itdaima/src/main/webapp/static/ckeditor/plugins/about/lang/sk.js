﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'sk', {
	copy: 'Copyright &copy; $1. Všetky práva vyhradené.',
	dlgTitle: 'O CKEditor-e',
	help: 'Zaškrtnite $1 pre pomoc.',
	moreInfo: 'Pre informácie o licenciách, prosíme, navštívte našu web stránku:',
	title: 'O CKEditor-e',
	userGuide: 'Používateľská príručka KCEditor-a'
});
