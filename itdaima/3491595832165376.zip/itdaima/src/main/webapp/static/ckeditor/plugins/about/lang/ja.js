﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'ja', {
	copy: 'Copyright &copy; $1. All rights reserved.',
	dlgTitle: 'CKEditorバージョン情報',
	help: 'Check $1 for help.', // MISSING
	moreInfo: 'ライセンス情報の詳細はウェブサイトにて確認してください:',
	title: 'CKEditorバージョン情報',
	userGuide: 'CKEditor User\'s Guide'
});
