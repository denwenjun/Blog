﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'zh', {
	copy: 'Copyright &copy; $1. All rights reserved.',
	dlgTitle: '關於 CKEditor',
	help: 'Check $1 for help.', // MISSING
	moreInfo: '訪問我們的網站以獲取更多關於協議的信息',
	title: '關於 CKEditor',
	userGuide: 'CKEditor User\'s Guide'
});
