﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'lt', {
	copy: 'Copyright &copy; $1. Visos teiss saugomos.',
	dlgTitle: 'Apie CKEditor',
	help: 'Patikrinkite $1 dėl pagalbos.',
	moreInfo: 'Dėl licencijavimo apsilankykite mūsų svetainėje:',
	title: 'Apie CKEditor',
	userGuide: 'CKEditor Vartotojo Gidas'
});
